--
-- Database: `noitha17_minhdoan`
--

-- --------------------------------------------------------

--
-- Table structure for table `administrator`
--

CREATE TABLE `administrator` (
  `id` varchar(220) NOT NULL DEFAULT '',
  `description` varchar(500) NOT NULL,
  `joinTime` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `lastTime` int(11) NOT NULL,
  `role` int(11) NOT NULL,
  `rememberKey` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `administrator`
--

INSERT INTO `administrator` (`id`, `description`, `joinTime`, `active`, `lastTime`, `role`, `rememberKey`) VALUES
('ducquan135@gmail.com', 'aaaaa', 0, 1, 1483948304, 1, ''),
('haohao.biz@gmail.com', 'Tên : nguyen hao , giới tính : male', 1462335069, 1, 1462335069, 0, ''),
('huychuc01@gmail.com', 'Tên : Chức Lại , giới tính : male', 1462331478, 1, 1463207573, 0, ''),
('liemnh267@gmail.com', 'Tên : Nguyễn Hoàng Liêm , giới tính : male', 1462413645, 1, 1483948366, 0, ''),
('nguyenhoa13288@gmail.com', 'Tên : Nguyen Hoa , giới tính : female', 1462759032, 0, 1462759033, 0, ''),
('othoa@gimasys.com', 'Tên : Hòa Ong Thế , giới tính : male', 1462243337, 1, 1462845944, 0, ''),
('phananh1304@gmail.com', 'Tên : Anh Phan , giới tính : male', 1462715159, 1, 1462715163, 0, ''),
('ppanh@gimasys.com', 'Tên : Anh Phan , giới tính : male', 1462335274, 1, 1462335574, 0, ''),
('thehoa268@gmail.com', 'Tên : Thế Hòa Ong , giới tính : male', 1462266785, 1, 1462368270, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE `auth_assignment` (
  `item_name` varchar(64) NOT NULL,
  `user_id` varchar(64) NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('administrator_assignment', 'ducquan135@gmail.com', 1462344213),
('administrator_assignment', 'huychuc01@gmail.com', 1462344206),
('administrator_assignment', 'liemnh267@gmail.com', 1483947989),
('administrator_assignment', 'othoa@gimasys.com', 1462344762),
('administrator_changeactive', 'ducquan135@gmail.com', 1462344213),
('administrator_changeactive', 'huychuc01@gmail.com', 1462344206),
('administrator_changeactive', 'liemnh267@gmail.com', 1483947989),
('administrator_changeactive', 'othoa@gimasys.com', 1462344762),
('administrator_grid', 'ducquan135@gmail.com', 1462344213),
('administrator_grid', 'huychuc01@gmail.com', 1462344206),
('administrator_grid', 'liemnh267@gmail.com', 1483947989),
('administrator_grid', 'othoa@gimasys.com', 1462344762),
('banner_add', 'ducquan135@gmail.com', 1462344213),
('banner_add', 'huychuc01@gmail.com', 1462344206),
('banner_add', 'liemnh267@gmail.com', 1483947989),
('banner_add', 'othoa@gimasys.com', 1462344762),
('banner_changeactive', 'ducquan135@gmail.com', 1462344213),
('banner_changeactive', 'huychuc01@gmail.com', 1462344206),
('banner_changeactive', 'liemnh267@gmail.com', 1483947989),
('banner_changeactive', 'othoa@gimasys.com', 1462344762),
('banner_get', 'ducquan135@gmail.com', 1462344213),
('banner_get', 'huychuc01@gmail.com', 1462344206),
('banner_get', 'liemnh267@gmail.com', 1483947989),
('banner_get', 'othoa@gimasys.com', 1462344762),
('banner_grid', 'ducquan135@gmail.com', 1462344213),
('banner_grid', 'huychuc01@gmail.com', 1462344206),
('banner_grid', 'liemnh267@gmail.com', 1483947989),
('banner_grid', 'othoa@gimasys.com', 1462344762),
('banner_remove', 'ducquan135@gmail.com', 1462344213),
('banner_remove', 'huychuc01@gmail.com', 1462344206),
('banner_remove', 'liemnh267@gmail.com', 1483947989),
('banner_remove', 'othoa@gimasys.com', 1462344762),
('category_add', 'ducquan135@gmail.com', 1462344213),
('category_add', 'huychuc01@gmail.com', 1462344206),
('category_add', 'liemnh267@gmail.com', 1483947989),
('category_add', 'othoa@gimasys.com', 1462344762),
('category_changeactive', 'ducquan135@gmail.com', 1462344213),
('category_changeactive', 'huychuc01@gmail.com', 1462344206),
('category_changeactive', 'liemnh267@gmail.com', 1483947989),
('category_changeactive', 'othoa@gimasys.com', 1462344762),
('category_changeposition', 'ducquan135@gmail.com', 1462344213),
('category_changeposition', 'huychuc01@gmail.com', 1462344206),
('category_changeposition', 'liemnh267@gmail.com', 1483947989),
('category_changeposition', 'othoa@gimasys.com', 1462344762),
('category_edit', 'ducquan135@gmail.com', 1462344213),
('category_edit', 'huychuc01@gmail.com', 1462344206),
('category_edit', 'liemnh267@gmail.com', 1483947989),
('category_edit', 'othoa@gimasys.com', 1462344762),
('category_get', 'ducquan135@gmail.com', 1462344213),
('category_get', 'huychuc01@gmail.com', 1462344206),
('category_get', 'liemnh267@gmail.com', 1483947989),
('category_get', 'othoa@gimasys.com', 1462344762),
('category_getall', 'ducquan135@gmail.com', 1462344213),
('category_getall', 'huychuc01@gmail.com', 1462344206),
('category_getall', 'liemnh267@gmail.com', 1483947990),
('category_getall', 'othoa@gimasys.com', 1462344762),
('category_getallactive', 'ducquan135@gmail.com', 1462344213),
('category_getallactive', 'huychuc01@gmail.com', 1462344206),
('category_getallactive', 'liemnh267@gmail.com', 1483947990),
('category_getallactive', 'othoa@gimasys.com', 1462344762),
('category_grid', 'ducquan135@gmail.com', 1462344213),
('category_grid', 'huychuc01@gmail.com', 1462344206),
('category_grid', 'liemnh267@gmail.com', 1483947990),
('category_grid', 'othoa@gimasys.com', 1462344762),
('category_remove', 'ducquan135@gmail.com', 1462344213),
('category_remove', 'huychuc01@gmail.com', 1462344206),
('category_remove', 'liemnh267@gmail.com', 1483947990),
('category_remove', 'othoa@gimasys.com', 1462344762),
('contact_change', 'ducquan135@gmail.com', 1462344213),
('contact_change', 'huychuc01@gmail.com', 1462344206),
('contact_change', 'liemnh267@gmail.com', 1483947990),
('contact_change', 'othoa@gimasys.com', 1462344762),
('contact_get', 'ducquan135@gmail.com', 1462344213),
('contact_get', 'huychuc01@gmail.com', 1462344206),
('contact_get', 'liemnh267@gmail.com', 1483947990),
('contact_get', 'othoa@gimasys.com', 1462344762),
('contact_grid', 'ducquan135@gmail.com', 1462344213),
('contact_grid', 'huychuc01@gmail.com', 1462344206),
('contact_grid', 'liemnh267@gmail.com', 1483947990),
('contact_grid', 'othoa@gimasys.com', 1462344762),
('contact_remove', 'ducquan135@gmail.com', 1462344213),
('contact_remove', 'huychuc01@gmail.com', 1462344206),
('contact_remove', 'liemnh267@gmail.com', 1483947990),
('contact_remove', 'othoa@gimasys.com', 1462344762),
('design_add', 'liemnh267@gmail.com', 1483947990),
('function_authgroupsave', 'ducquan135@gmail.com', 1462344213),
('function_authgroupsave', 'huychuc01@gmail.com', 1462344206),
('function_authgroupsave', 'liemnh267@gmail.com', 1483947990),
('function_authgroupsave', 'othoa@gimasys.com', 1462344762),
('function_authitemsave', 'ducquan135@gmail.com', 1462344213),
('function_authitemsave', 'huychuc01@gmail.com', 1462344206),
('function_authitemsave', 'liemnh267@gmail.com', 1483947990),
('function_authitemsave', 'othoa@gimasys.com', 1462344762),
('function_getassignment', 'ducquan135@gmail.com', 1462344213),
('function_getassignment', 'huychuc01@gmail.com', 1462344206),
('function_getassignment', 'liemnh267@gmail.com', 1483947990),
('function_getassignment', 'othoa@gimasys.com', 1462344762),
('function_grid', 'ducquan135@gmail.com', 1462344213),
('function_grid', 'huychuc01@gmail.com', 1462344206),
('function_grid', 'liemnh267@gmail.com', 1483947990),
('function_grid', 'othoa@gimasys.com', 1462344762),
('item_add', 'ducquan135@gmail.com', 1462344213),
('item_add', 'huychuc01@gmail.com', 1462344206),
('item_add', 'liemnh267@gmail.com', 1483947990),
('item_add', 'othoa@gimasys.com', 1462344762),
('item_changeactive', 'ducquan135@gmail.com', 1462344213),
('item_changeactive', 'huychuc01@gmail.com', 1462344206),
('item_changeactive', 'liemnh267@gmail.com', 1483947990),
('item_changeactive', 'othoa@gimasys.com', 1462344762),
('item_edit', 'ducquan135@gmail.com', 1462344213),
('item_edit', 'huychuc01@gmail.com', 1462344206),
('item_edit', 'liemnh267@gmail.com', 1483947990),
('item_edit', 'othoa@gimasys.com', 1462344762),
('item_getbyid', 'ducquan135@gmail.com', 1462344213),
('item_getbyid', 'huychuc01@gmail.com', 1462344206),
('item_getbyid', 'liemnh267@gmail.com', 1483947990),
('item_getbyid', 'othoa@gimasys.com', 1462344762),
('item_grid', 'ducquan135@gmail.com', 1462344213),
('item_grid', 'huychuc01@gmail.com', 1462344206),
('item_grid', 'liemnh267@gmail.com', 1483947990),
('item_grid', 'othoa@gimasys.com', 1462344762),
('item_remove', 'ducquan135@gmail.com', 1462344213),
('item_remove', 'huychuc01@gmail.com', 1462344206),
('item_remove', 'liemnh267@gmail.com', 1483947990),
('item_remove', 'othoa@gimasys.com', 1462344762),
('item_savedetail', 'ducquan135@gmail.com', 1462344213),
('item_savedetail', 'huychuc01@gmail.com', 1462344206),
('item_savedetail', 'liemnh267@gmail.com', 1483947990),
('item_savedetail', 'othoa@gimasys.com', 1462344762),
('news_add', 'ducquan135@gmail.com', 1462344213),
('news_add', 'huychuc01@gmail.com', 1462344206),
('news_add', 'liemnh267@gmail.com', 1483947990),
('news_add', 'othoa@gimasys.com', 1462344762),
('news_changeactive', 'ducquan135@gmail.com', 1462344213),
('news_changeactive', 'huychuc01@gmail.com', 1462344206),
('news_changeactive', 'liemnh267@gmail.com', 1483947990),
('news_changeactive', 'othoa@gimasys.com', 1462344762),
('news_getbyid', 'ducquan135@gmail.com', 1462344213),
('news_getbyid', 'huychuc01@gmail.com', 1462344206),
('news_getbyid', 'liemnh267@gmail.com', 1483947990),
('news_getbyid', 'othoa@gimasys.com', 1462344762),
('news_grid', 'ducquan135@gmail.com', 1462344213),
('news_grid', 'huychuc01@gmail.com', 1462344206),
('news_grid', 'liemnh267@gmail.com', 1483947990),
('news_grid', 'othoa@gimasys.com', 1462344762),
('news_remove', 'ducquan135@gmail.com', 1462344213),
('news_remove', 'huychuc01@gmail.com', 1462344206),
('news_remove', 'liemnh267@gmail.com', 1483947990),
('news_remove', 'othoa@gimasys.com', 1462344762);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE `auth_item` (
  `name` varchar(64) NOT NULL,
  `type` int(11) NOT NULL,
  `description` text,
  `rule_name` varchar(64) DEFAULT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `alias` varchar(50) NOT NULL,
  `groupId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`, `alias`, `groupId`) VALUES
('administrator', 1, 'create By system admin', NULL, NULL, 1462344150, 1483947949, 'Quản trị admin', 1),
('administrator_assignment', 2, 'create By system admin', NULL, NULL, 1462344152, 1462344152, 'Cấp quyền', 0),
('administrator_changeactive', 2, 'create By system admin', NULL, NULL, 1462344151, 1462344151, 'Khóa hoặc mở khóa', 0),
('administrator_grid', 2, 'create By system admin', NULL, NULL, 1462344151, 1483947951, 'Danh sách', 0),
('banner', 1, 'create By system admin', NULL, NULL, 1462343962, 1462343962, 'Quản tri banner', 4),
('banner_add', 2, 'create By system admin', NULL, NULL, 1462343965, 1462343965, 'Thêm mới', 0),
('banner_changeactive', 2, 'create By system admin', NULL, NULL, 1462343963, 1462343963, 'Đổi trạng thái hoạt động', 0),
('banner_get', 2, 'create By system admin', NULL, NULL, 1462343965, 1462343965, 'Chi tiết banner', 0),
('banner_grid', 2, 'create By system admin', NULL, NULL, 1462343962, 1462343962, 'Danh sách', 0),
('banner_remove', 2, 'create By system admin', NULL, NULL, 1462343963, 1462343963, 'Xóa', 0),
('category', 1, 'create By system admin', NULL, NULL, 1462344058, 1462344058, 'Quản trị danh mục sản phẩm', 2),
('category_add', 2, 'create By system admin', NULL, NULL, 1462344061, 1462344061, 'Thêm', 0),
('category_changeactive', 2, 'create By system admin', NULL, NULL, 1462344059, 1462344059, 'Đổi trạng thái hoạt động', 0),
('category_changeposition', 2, 'create By system admin', NULL, NULL, 1462344059, 1462344059, 'Đổi thứ tự hiển thị', 0),
('category_edit', 2, 'create By system admin', NULL, NULL, 1462344062, 1462344062, 'Sửa', 0),
('category_get', 2, 'create By system admin', NULL, NULL, 1462344062, 1462344062, 'Lấy chi tiết', 0),
('category_getall', 2, 'create By system admin', NULL, NULL, 1462344060, 1462344060, 'Lấy tất cả', 0),
('category_getallactive', 2, 'create By system admin', NULL, NULL, 1462344063, 1462344063, 'Lấy tất cả danh mục đang hoạt động', 0),
('category_grid', 2, 'create By system admin', NULL, NULL, 1462344058, 1462344058, 'Danh sách', 0),
('category_remove', 2, 'create By system admin', NULL, NULL, 1462344060, 1462344060, 'Xóa', 0),
('contact', 1, 'create By system admin', NULL, NULL, 1462343958, 1462343958, 'Quản trị liên hệ', 5),
('contact_change', 2, 'create By system admin', NULL, NULL, 1462343960, 1462343960, 'contact_change', 0),
('contact_get', 2, 'create By system admin', NULL, NULL, 1462343960, 1462343960, 'Chi tiết liên hệ', 0),
('contact_grid', 2, 'create By system admin', NULL, NULL, 1462343958, 1462343958, 'Danh sách liên hệ', 0),
('contact_remove', 2, 'create By system admin', NULL, NULL, 1462343959, 1462343959, 'Xóa liên hệ', 0),
('design', 1, 'create By system admin', NULL, NULL, 1462343996, 1462343996, 'Quản trị thiết kế nội thất', 6),
('design_add', 2, 'create By system admin', NULL, NULL, 1462343996, 1462343996, 'Thêm mới', 0),
('function', 1, 'create By system admin', NULL, NULL, 1462344183, 1462344183, 'Định nghĩa quyền hệ thống', 1),
('function_authgroupsave', 2, 'create By system admin', NULL, NULL, 1462344184, 1462344184, 'Lưu nhóm quyền', 0),
('function_authitemsave', 2, 'create By system admin', NULL, NULL, 1462344185, 1462344185, 'Lưu quyền', 0),
('function_getassignment', 2, 'create By system admin', NULL, NULL, 1462344185, 1462344185, 'Lấy quyền', 0),
('function_grid', 2, 'create By system admin', NULL, NULL, 1462344184, 1462344184, 'Danh sách quyền', 0),
('item', 1, 'create By system admin', NULL, NULL, 1462344126, 1462344126, 'Quản trị sản phẩm', 2),
('item_add', 2, 'create By system admin', NULL, NULL, 1462344126, 1462344126, 'Thêm', 0),
('item_changeactive', 2, 'create By system admin', NULL, NULL, 1462344127, 1462344127, 'Đổi trạng thái hoạt động', 0),
('item_edit', 2, 'create By system admin', NULL, NULL, 1462344129, 1462344129, 'Sửa', 0),
('item_getbyid', 2, 'create By system admin', NULL, NULL, 1462344127, 1462344127, 'Lấy chi tiết sản phẩm', 0),
('item_grid', 2, 'create By system admin', NULL, NULL, 1462344126, 1462344126, 'Danh sách', 0),
('item_remove', 2, 'create By system admin', NULL, NULL, 1462344129, 1462344129, 'Xóa', 0),
('item_savedetail', 2, 'create By system admin', NULL, NULL, 1462344127, 1462344127, 'Lưu chi tiết', 0),
('news', 1, 'create By system admin', NULL, NULL, 1462343996, 1462343996, 'Quản trị tin tức, hoạt động', 3),
('news_add', 2, 'create By system admin', NULL, NULL, 1462343996, 1462343996, 'Thêm mới', 0),
('news_changeactive', 2, 'create By system admin', NULL, NULL, 1462343997, 1462343997, 'Đổi trạng thái hoạt động', 0),
('news_getbyid', 2, 'create By system admin', NULL, NULL, 1462343997, 1462343997, 'Lấy theo mã', 0),
('news_grid', 2, 'create By system admin', NULL, NULL, 1462343996, 1462343996, 'Danh sách', 0),
('news_remove', 2, 'create By system admin', NULL, NULL, 1462343997, 1462343997, 'Xóa', 0);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE `auth_item_child` (
  `parent` varchar(64) NOT NULL,
  `child` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('administrator', 'administrator_assignment'),
('administrator', 'administrator_changeactive'),
('administrator', 'administrator_grid'),
('banner', 'banner_add'),
('banner', 'banner_changeactive'),
('banner', 'banner_get'),
('banner', 'banner_grid'),
('banner', 'banner_remove'),
('category', 'category_add'),
('category', 'category_changeactive'),
('category', 'category_changeposition'),
('category', 'category_edit'),
('category', 'category_get'),
('category', 'category_getall'),
('category', 'category_getallactive'),
('category', 'category_grid'),
('category', 'category_remove'),
('contact', 'contact_change'),
('contact', 'contact_get'),
('contact', 'contact_grid'),
('contact', 'contact_remove'),
('design', 'design_add'),
('design', 'design_grid'),
('function', 'function_authgroupsave'),
('function', 'function_authitemsave'),
('function', 'function_getassignment'),
('function', 'function_grid'),
('item', 'item_add'),
('item', 'item_changeactive'),
('item', 'item_edit'),
('item', 'item_getbyid'),
('item', 'item_grid'),
('item', 'item_remove'),
('item', 'item_savedetail'),
('news', 'news_add'),
('news', 'news_changeactive'),
('news', 'news_getbyid'),
('news', 'news_grid'),
('news', 'news_remove');

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_group`
--

CREATE TABLE `auth_item_group` (
  `id` int(11) NOT NULL,
  `name` varchar(220) NOT NULL,
  `position` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_item_group`
--

INSERT INTO `auth_item_group` (`id`, `name`, `position`) VALUES
(1, 'Hệ thống', 1),
(2, 'Sản phẩm', 1),
(3, 'Tin tức', 1),
(4, 'Banner quảng cáo', 1),
(5, 'Liên hệ', 1),
(6, 'Thiết kế nội thất', 1);

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE `auth_rule` (
  `name` varchar(64) NOT NULL,
  `data` text,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `banner`
--

CREATE TABLE `banner` (
  `id` int(11) NOT NULL,
  `name` varchar(500) NOT NULL,
  `active` int(11) NOT NULL,
  `link` varchar(500) DEFAULT NULL,
  `type` varchar(32) NOT NULL,
  `position` int(11) NOT NULL,
  `description` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `banner`
--

INSERT INTO `banner` (`id`, `name`, `active`, `link`, `type`, `position`, `description`) VALUES
(6, 'Ảnh 1', 1, NULL, 'heart', 1, 'Ảnh 1'),
(7, 'anh 2', 1, 'http://dogonoithat', 'heart', 2, 'a'),
(8, 'anh 3', 1, 'http://localhost/minhdoan/frontend/public/index.html', 'heart', 3, 'kch'),
(9, 'Hiện đại', 1, 'http://localhost/minhdoan/frontend/public/san-pham.html?prototype=modern', 'center', 0, 'Hiện đại'),
(10, 'Cổ điển', 1, 'http://localhost/minhdoan/frontend/public/san-pham.html?prototype=classic', 'center', 1, 'Cổ điển'),
(11, 'Thủ công mỹ nghệ', 1, 'http://localhost/minhdoan/frontend/public/san-pham.html?prototype=crafts', 'center', 2, 'Thủ công mỹ nghệ');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(220) NOT NULL,
  `createTime` int(11) NOT NULL,
  `updateTime` int(11) NOT NULL,
  `parentId` int(11) NOT NULL,
  `active` int(11) NOT NULL,
  `position` int(11) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `leaf` int(11) NOT NULL DEFAULT '0',
  `level` int(11) NOT NULL,
  `path` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `createTime`, `updateTime`, `parentId`, `active`, `position`, `description`, `leaf`, `level`, `path`) VALUES
(6, 'Phòng ngủ', 1462807292, 1462807292, 0, 1, 1, 'chuyển phòng ngủ', 0, 1, '[6]'),
(7, 'phòng khách', 1462807310, 1462807310, 0, 1, 2, 'chuyển phòng khách', 0, 1, '[7]'),
(8, 'Phòng ăn', 1462807330, 1462807330, 0, 1, 3, 'chuyển phòng ăn', 0, 1, '[8]'),
(9, 'Phòng làm việc', 1462807346, 1462807346, 0, 1, 4, 'chuyển phòng làm việc', 0, 1, '[9]'),
(10, 'Phòng thờ', 1462807365, 1462807365, 0, 1, 5, 'chuyển phòng thờ', 0, 1, '[10]'),
(11, 'Tượng', 1462807456, 1462807456, 0, 1, 6, 'Chuyên tượng', 0, 1, '[11]'),
(12, 'Giường ngủ', 1462807665, 1462807665, 6, 1, 1, 'Chuyên giường ngủ', 1, 2, '[6,12]'),
(13, 'Sập', 1462807688, 1462807688, 6, 1, 2, 'Các loại sập đẹp', 1, 2, '[6,13]'),
(14, 'Phản', 1462807704, 1462807716, 6, 1, 3, 'Các loại phản', 1, 2, '[6,14]'),
(15, 'Bàn trang điểm', 1462807785, 1462807785, 6, 1, 4, 'Chuyên các loại bàn trang điểm', 1, 2, '[6,15]'),
(16, 'Bàn trà phòng ngủ', 1462807807, 1462807812, 6, 1, 5, 'Các loại bàn trà đẹp', 1, 2, '[6,16]'),
(17, 'Tủ quần áo', 1462807856, 1462807856, 6, 1, 6, 'Các loại tủ quần áo nhiều mẫu mã', 1, 2, '[6,17]'),
(18, 'Tủ ngăn kéo', 1462807873, 1462807880, 6, 1, 7, 'Tủ ngăn kéo', 1, 2, '[6,18]'),
(19, 'Tủ đầu giường', 1462807890, 1462807896, 6, 1, 8, 'Tủ đầu giường', 1, 2, '[6,19]'),
(20, 'Chiếu gỗ', 1462807921, 1462807926, 6, 1, 9, 'Chiếu nhiều kích cỡ', 1, 2, '[6,20]'),
(21, 'Bộ salon tay 10 (6 món)', 1462808020, 1462808020, 7, 1, 1, 'Bộ salon tay 10 (6 món)', 1, 2, '[7,21]'),
(22, 'Bộ salon tay 10 (8 món)', 1462808041, 1462808146, 7, 1, 2, 'Bộ salon tay 10 (8 món)', 1, 2, '[7,22]'),
(23, 'Bộ salon tay 10 (10 món)', 1462808059, 1462808139, 7, 1, 3, 'Bộ salon tay 10 (10 món)', 1, 2, '[7,23]'),
(24, 'Bộ salon tay 12 (6 món)', 1462808084, 1462808129, 7, 1, 4, 'Bộ salon tay 12 (6 món)', 1, 2, '[7,24]'),
(25, 'Bộ salon tay 12 (8 món)', 1462808095, 1462808120, 7, 1, 5, 'Bộ salon tay 12 (8 món)', 1, 2, '[7,25]'),
(26, 'Bộ salon tay 12 (10 món)', 1462808115, 1462808115, 7, 1, 6, 'Bộ salon tay 12 (10 món)', 1, 2, '[7,26]'),
(27, 'Kệ tivi', 1462808193, 1462808193, 7, 1, 7, 'Kệ tivi', 1, 2, '[7,27]'),
(28, 'Tủ rượu', 1462808214, 1462808214, 7, 1, 8, 'Tủ rượu', 1, 2, '[7,28]'),
(29, 'Tủ giày dép', 1462808232, 1462808232, 7, 1, 9, 'Tủ giày dép', 1, 2, '[7,29]'),
(30, 'Giá kệ bày đồ', 1462808271, 1462808271, 7, 1, 10, 'Giá kệ bày đồ', 1, 2, '[7,30]'),
(31, 'Bàn consol trang trí', 1462808294, 1462808294, 7, 1, 11, 'Bàn consol trang trí', 1, 2, '[7,31]'),
(32, 'Bình phong', 1462808311, 1462808311, 7, 1, 12, 'Bình phong', 1, 2, '[7,32]'),
(33, 'Tranh treo tường', 1462808331, 1462808339, 7, 1, 13, 'Tranh treo tường', 1, 2, '[7,33]'),
(34, 'Lọ lục bình', 1462808364, 1462808364, 7, 1, 14, 'Lọ lục bình', 1, 2, '[7,34]'),
(35, 'Đồng hồ', 1462808382, 1462808382, 7, 1, 15, 'Đồng hồ', 1, 2, '[7,35]'),
(36, 'Gương', 1462808396, 1462808396, 7, 1, 16, 'Gương', 1, 2, '[7,36]'),
(37, 'Đôn', 1462808405, 1462808405, 7, 1, 17, 'Đôn', 1, 2, '[7,37]'),
(38, 'Tủ bếp trên', 1462808438, 1462808438, 8, 1, 1, 'Tủ bếp trên', 1, 2, '[8,38]'),
(39, 'Tủ bếp dưới', 1462808450, 1462808450, 8, 1, 2, 'Tủ bếp dưới', 1, 2, '[8,39]'),
(40, 'Quầy bar', 1462808465, 1462808465, 8, 1, 3, 'Quầy bar', 1, 2, '[8,40]'),
(41, 'Bộ bàn ăn', 1462808477, 1462808477, 8, 1, 3, 'Bộ bàn ăn', 1, 2, '[8,41]'),
(42, 'Giá sách', 1462808498, 1462808498, 9, 1, 1, 'Giá sách', 1, 2, '[9,42]'),
(43, 'Bàn làm việc', 1462808518, 1462808518, 9, 1, 2, 'Bàn làm việc', 1, 2, '[9,43]'),
(44, 'Tủ thờ', 1462808539, 1462808557, 10, 1, 1, 'Tủ thờ', 1, 2, '[10,44]'),
(45, 'Bàn thờ', 1462808551, 1462808551, 10, 1, 2, 'Bàn thờ', 1, 2, '[10,45]'),
(46, 'Bàn thờ thần tài', 1462808575, 1462808575, 10, 1, 3, 'Bàn thờ thần tài', 1, 2, '[10,46]'),
(47, 'Hoành phi - Câu đối', 1462808592, 1462808592, 10, 1, 4, 'Hoành phi - Câu đối', 1, 2, '[10,47]'),
(48, 'Bộ 3 ông Tam Đa', 1462808618, 1462808618, 11, 1, 1, 'Bộ 3 ông Tam Đa', 1, 2, '[11,48]'),
(49, 'Ông Đạt Ma', 1462808634, 1462808643, 11, 1, 2, 'Ông Đạt Ma', 1, 2, '[11,49]'),
(51, 'Ông Thần Tài', 1462808665, 1462808665, 11, 1, 3, 'Ông Thần Tài', 1, 2, '[11,51]'),
(52, 'Ông Di Lặc', 1462808689, 1462808879, 11, 1, 4, 'Ông Di Lặc', 1, 2, '[11,52]'),
(53, 'Ông Quan Công', 1462808703, 1462808703, 11, 1, 6, 'Ông Quan Công', 1, 2, '[11,53]'),
(54, 'Ông Quan Khổng Minh', 1462808729, 1462808920, 11, 1, 7, 'Ông Quan Khổng Minh', 1, 2, '[11,54]'),
(55, 'Ông Thiềm Thử (Cóc)', 1462808952, 1462808952, 11, 1, 8, 'Ông Thiềm Thử (Cóc)', 1, 2, '[11,55]'),
(56, 'Trang chủ', 1463115346, 1463115346, 0, 1, 6, 'trang chủ', 1, 1, '[56]');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `createTime` int(11) NOT NULL,
  `name` varchar(220) NOT NULL,
  `phone` int(11) NOT NULL,
  `email` varchar(220) NOT NULL,
  `note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `createTime`, `name`, `phone`, `email`, `note`) VALUES
(3, 1462370192, 'a', 0, 'ád', 'ádasd'),
(4, 1483929966, 'sdf', 234234, 'liemnh267@gmail.com', '234234234');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `targetId` varchar(220) NOT NULL,
  `position` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `imageId` varchar(220) NOT NULL,
  `extension` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`id`, `targetId`, `position`, `type`, `width`, `height`, `imageId`, `extension`) VALUES
(36, '5', 1, 'news', 0, 0, '/news/target_5/avatarjpg-1483931045.jpeg', 'jpeg'),
(37, '4', 1, 'news', 0, 0, '/news/target_4/avatarjpg-1483932953.jpeg', 'jpeg'),
(38, '3', 1, 'news', 0, 0, '/news/target_3/1png-1483932965.png', 'png'),
(39, '2', 1, 'news', 0, 0, '/news/target_2/avatarjpg-1483932981.jpeg', 'jpeg'),
(40, 'TC001', 1, 'item', 0, 0, '/item/target_tc001/banner3jpg-1483933042.jpeg', 'jpeg'),
(41, 'SL008', 1, 'item', 0, 0, '/item/target_sl008/p3jpg-1483933070.jpeg', 'jpeg'),
(42, 'SL007', 1, 'item', 0, 0, '/item/target_sl007/banner2jpg-1483933110.jpeg', 'jpeg'),
(43, 'SL006', 1, 'item', 0, 0, '/item/target_sl006/s3jpg-1483933214.jpeg', 'jpeg'),
(44, '10', 1, 'banner', 0, 0, '/banner/target_10/banner1jpg-1483933262.jpeg', 'jpeg'),
(45, '6', 1, 'banner', 0, 0, '/banner/target_6/banner2jpg-1483933276.jpeg', 'jpeg'),
(46, '11', 1, 'banner', 0, 0, '/banner/target_11/banner3jpg-1483933282.jpeg', 'jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` varchar(32) NOT NULL,
  `name` varchar(500) NOT NULL,
  `categoryId` int(11) NOT NULL,
  `createTime` int(11) NOT NULL,
  `updateTime` int(11) NOT NULL,
  `sellPrice` double NOT NULL,
  `description` text,
  `details` text,
  `viewCount` int(11) NOT NULL DEFAULT '0',
  `active` int(11) NOT NULL DEFAULT '0',
  `createEmail` varchar(220) NOT NULL,
  `special` int(11) NOT NULL DEFAULT '0',
  `bestSelling` int(11) NOT NULL DEFAULT '0',
  `suggest` int(11) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT '0',
  `updateEmail` varchar(220) DEFAULT NULL,
  `quantity` int(11) DEFAULT '0',
  `color` varchar(500) DEFAULT NULL,
  `size` varchar(500) DEFAULT NULL,
  `prototype` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `name`, `categoryId`, `createTime`, `updateTime`, `sellPrice`, `description`, `details`, `viewCount`, `active`, `createEmail`, `special`, `bestSelling`, `suggest`, `position`, `updateEmail`, `quantity`, `color`, `size`, `prototype`) VALUES
('SL001', 'Salon', 21, 1463207654, 1463207654, 1000000000, 'nothing', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 0, 1, 'huychuc01@gmail.com', 1, 'đen | đỏ | trắng', '12x12x12', 'modern'),
('SL002', 'Salon da', 21, 1463207698, 1463207698, 1555555555, 'đẹp', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 1, 'huychuc01@gmail.com', 1, 'đen', '12x12x12', 'modern'),
('SL003', 'Salon đẹp', 22, 1463207740, 1463207740, 144444444, 'đẹp', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 3, 'huychuc01@gmail.com', 1, 'trắng', '12x12x12', 'classic'),
('SL004', 'Salon đẹp', 23, 1463207781, 1463207781, 500000000000, 'đẹp', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 4, 'huychuc01@gmail.com', 1, 'đen', '12x12x12', 'classic'),
('SL005', 'Salon da', 24, 1463207903, 1463207903, 100000000, 'đẹp', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 5, 'huychuc01@gmail.com', 2, 'trắng', '12x12x12', 'modern'),
('SL006', 'Salon mới', 25, 1463207935, 1463207935, 100000000000000, 'đẹp', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 6, 'huychuc01@gmail.com', 1, 'hồng', '12x12x12', 'classic'),
('SL007', 'SALON', 26, 1463208068, 1463208068, 10000000000000, 'SL007', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 7, 'huychuc01@gmail.com', 12, 'ĐEN', '12X12X12', 'classic'),
('SL008', 'SALON MỚI', 25, 1463208105, 1463208105, 11111111111111, 'ĐẸP', '<p>Mẫu&nbsp;<strong>Sofa da thật&nbsp;Vigo F1623&nbsp;</strong>mang đậm phong c&aacute;ch hiện đại, sang trọng. Mẫu sofa da thật F1623&nbsp;được Goby nhập khẩu nguy&ecirc;n chiếc, sản phẩm sofa Vigo F1623 được sản xuất với những&nbsp;đường n&eacute;t khỏe khắn v&agrave; tinh tế mang đậm phong chất &Yacute;. Sofa da thật lu&ocirc;n tạo ra sự kh&aacute;c biệt trong kh&ocirc;ng&nbsp;gian nội thất ch&iacute;nh v&igrave; vậy nếu muốn tạo ra sự kh&aacute;c biệt mới lạ trong kh&ocirc;ng gian, h&atilde;y thử với mẫu sofa da thật Vigo F1623 của<em>F1623 thể hiện đẳng cấp sang trọng lịch l&atilde;m</em></p>\n\n<h2><strong>Đặc điểm chi tiết sản phẩm:</strong></h2>\n\n<ul>\n	<li>Sofa Vigo F1623 được cấu tạo với chất liệu da thật loại da b&ograve; nhập khẩu từ &Yacute;. (<strong>Xem video thử nghiệm chất liệu da của Goby</strong>)</li>\n	<li>Khung sofa được l&agrave;m bằng gỗ tự nhi&ecirc;n chắc chắn (loại gỗ Sồi - Song tử diệp), được xử l&yacute; để chống cong v&ecirc;nh v&agrave; mối mọt.</li>\n	<li>L&ograve; xo của sofa Vigo F1623 được l&agrave;m bằng th&eacute;p đ&uacute;c c&oacute; độ bền vượt&nbsp;10 năm.</li>\n	<li>Đệm sofa F1623 c&oacute; độ d&agrave;y 15 - 20 cm (Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể lựa chọn loại đệm cứng, mềm t&ugrave;y sở th&iacute;ch bản th&acirc;n.)</li>\n	<li>Ch&acirc;n ghế sử dụng l&agrave; loại ch&acirc;n gỗ&nbsp;chắc chắn v&agrave; c&oacute; t&iacute;nh thẩm mỹ cao.</li>\n	<li>Phần ngồi của Sofa Vigo F1623 c&oacute;&nbsp;r&uacute;t l&otilde;m tạo điểm nhấn đặc biệt&nbsp;cho sản phẩm.</li>\n</ul>\n\n<p><em>(M&agrave;u sắc v&agrave; chất liệu của sofa ho&agrave;n to&agrave;n c&oacute; thể thay thế được t&ugrave;y theo y&ecirc;u cầu của kh&aacute;ch h&agrave;ng. Xem th&ecirc;m&nbsp;<a href="http://goby.vn/sofa-da-that-vigo-f1236">tại đ&acirc;y</a>)</em></p>\n\n<h3><strong>K&iacute;ch thước sản phẩm Vigo F1623:</strong></h3>\n\n<p><img alt="" src="http://goby.vn/sites/default/files/tin-tuc/kich-thuoc-sofa-mo-phong_0.jpg" /></p>\n\n<ul>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 3&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh&nbsp;vẽ</li>\n	<li>Đối với mẫu sofa Vigo F1623 gồm 4&nbsp;phần ngồi th&igrave; k&iacute;ch thước l&agrave;: 358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng)&nbsp;tương ứng (a x b x c)&nbsp;như tr&ecirc;n h&igrave;nh vẽ</li>\n</ul>\n\n<p><em>Ngo&agrave;i ra kh&aacute;ch h&agrave;ng c&oacute; thể t&ugrave;y chọn k&iacute;ch thước, chiều g&oacute;c chữ L&nbsp;theo y&ecirc;u cầu&nbsp;sao cho ho&agrave;n hảo nhất,&nbsp;ph&ugrave; hợp nhất với kh&ocirc;ng gian v&agrave;&nbsp;diện t&iacute;ch ng&ocirc;i&nbsp;nh&agrave; m&igrave;nh.</em></p>\n\n<p><strong>Chi tiết về mức gi&aacute; v&agrave; ch&iacute;nh s&aacute;ch chiết khấu khi mua&nbsp;<a href="http://goby.vn/sofa-da-that">sofa da thật</a>&nbsp;&nbsp;Vigo F1623:</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;283cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;47.300.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>40.205.000đ</strong></p>\n\n<p>Với k&iacute;ch thước&nbsp;358cm*180cm*95cm (d&agrave;i x rộng x s&acirc;u l&ograve;ng) c&oacute; gi&aacute; gốc ni&ecirc;m yết hiện tại l&agrave;:&nbsp;53.075.000đ&nbsp;GOBY khuyến m&atilde;i giảm 15% chỉ c&ograve;n&nbsp;<strong>45.113.000</strong></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 8, 'huychuc01@gmail.com', 1, 'ĐEN', '12X12X19', 'modern'),
('TC001', 'tranh', 25, 1463208144, 1463208144, 1788889999, 'tinh tế', '<p>Chi&ecirc;ng đồng huế ,cồng chi&ecirc;ng t&acirc;y nguy&ecirc;n</p>\n\n<p>Đồ Đồng Truyền Thống nhận đ&uacute;c c&aacute;c loại&nbsp;<strong>Chu&ocirc;ng Đồng, Chi&ecirc;ng đồng</strong>&nbsp;thờ c&uacute;ng theo y&ecirc;u cầu, từ c&aacute;c loại chu&ocirc;ng đồng nhỏ treo gi&aacute; gỗ nặng 3 - 8 kg để tại b&agrave;n thờ c&uacute;ng gia đ&igrave;nh cho đến những chu&ocirc;ng đồng c&oacute; khối lượng lớn hơn như nặng khoảng 20 - 50kg đặt tại nh&agrave; thờ họ tộc. Đặc biệt nhận đ&uacute;c c&aacute;c c&ocirc;ng tr&igrave;nh lớn như đ&uacute;c chu&ocirc;ng nặng 500kg, 1 tấn,... trở l&ecirc;n cho c&aacute;c đền ch&ugrave;a.</p>\n\n<p>Ng&agrave;y nay, để&nbsp;&nbsp;<em>Đ&uacute;c chu&ocirc;ng đồng</em>&nbsp;&nbsp;thờ c&uacute;ng c&oacute; rất nhiều xưởng hiện nay đ&atilde; l&agrave;m nhưng để đ&uacute;c chu&ocirc;ng đạt chuẩn cao nhất l&agrave; li&ecirc;n quan đến tiếng ng&acirc;n của chu&ocirc;ng v&agrave; c&aacute;c họa tiết tr&ecirc;n chu&ocirc;ng m&agrave; điều n&agrave;y kh&ocirc;ng phải cơ sở n&agrave;o cũng đạt được v&igrave; n&oacute; c&ograve;n li&ecirc;n quan đến kỹ thuật pha trộn nguy&ecirc;n liệu.</p>\n\n<p>Xưởng Đ&uacute;c Đồng Truyền Thống với kinh nghiệm&nbsp;<strong>Đ&uacute;c Chu&ocirc;ng Đồng Thờ C&uacute;ng</strong>&nbsp;l&acirc;u năm bởi b&agrave;n tay của c&aacute;c nghệ nh&acirc;n đ&uacute;c chu&ocirc;ng cao cấp đ&atilde; đ&uacute;c chu&ocirc;ng cho rất nhiều c&ocirc;ng tr&igrave;nh lớn kh&aacute;c nhau với những Quả chu&ocirc;ng c&oacute; khối lượng &gt; 1 tấn v&agrave; nhiều quả chu&ocirc;ng c&oacute; khối lượng kh&aacute;c nhau.</p>\n\n<p>Để đ&uacute;c chu&ocirc;ng đồng th&igrave; chỉ c&oacute; 2 d&ograve;ng kim loại cơ bản: Đồng v&agrave; Thiếc, ngo&agrave;i ra c&ograve;n c&oacute; thể c&oacute; v&agrave;ng nếu c&aacute;c gia chủ c&uacute;ng tiến bảo v&agrave;o.</p>\n\n<p><img src="http://g.vatgia.vn/gallery_img/2/dmh1455692932.jpg" /></p>\n', 0, 1, 'huychuc01@gmail.com', 1, 1, 1, 9, 'huychuc01@gmail.com', 1, 'trắng', '100x100x100', 'crafts');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `name` varchar(220) NOT NULL,
  `createTime` int(11) NOT NULL,
  `createEmail` varchar(220) NOT NULL,
  `updateTime` int(11) NOT NULL,
  `updateEmail` varchar(220) NOT NULL,
  `detail` text NOT NULL,
  `active` int(11) NOT NULL,
  `type` varchar(220) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `name`, `createTime`, `createEmail`, `updateTime`, `updateEmail`, `detail`, `active`, `type`, `description`) VALUES
(2, 'Thông tin chăm sóc khách hàng', 1462809400, 'huychuc01@gmail.com', 1462845996, 'othoa@gimasys.com', '<h3>Địa chỉ Showroom</h3>\n\n<p><strong>Hotline:</strong>&nbsp;0913098883 - 0989140805<br />\n<br />\n<strong>Showroom:&nbsp;</strong>..........................................................................., H&agrave; Nội<br />\n<strong>[T] :</strong>&nbsp;(04)..........<br />\n<strong>[E] :</strong>&nbsp;<a href="mailto:banhang@noithatgiakhanh.com" target="_blank">noithatminhdoanh666@gmail.com</a><br />\n<strong>[W] :</strong>&nbsp;<a href="http://www.noithatminhdoan.com">www.noithatminhdoan.com </a>/&nbsp;<a href="http://www.noithatminhdoan.vn">www.noithatminhdoan.vn</a></p>\n', 1, 'customer_care', 'Liên hệ với chúng tôi'),
(3, 'hoạt động 1', 1462809448, 'huychuc01@gmail.com', 1483932451, 'liemnh267@gmail.com', '<p>t&eacute;tttttttttttttttttttfggdfgdfg</p>\n', 1, 'activity', 'hoạt động 1hoạt động 1hoạt động 1'),
(4, 'Giới thiệu', 1462810627, 'huychuc01@gmail.com', 1462810712, 'huychuc01@gmail.com', '<p>Hiện nay, với thực trạng nguồn t&agrave;i nguy&ecirc;n thi&ecirc;n nhi&ecirc;n đang ng&agrave;y c&agrave;ng cạn kiệt m&agrave; nhu cầu đ&ograve;i hỏi của con người th&igrave; kh&ocirc;ng ngừng n&acirc;ng cao . Đặc biệt l&agrave; nguồn t&agrave;i nguy&ecirc;n Gỗ tự nhi&ecirc;n đang dần bị hao m&ograve;n v&igrave; những đ&ograve;i hỏi của ch&uacute;ng ta.<br />\nGỗ MINH ĐO&Agrave;N &ndash; Vốn đ&atilde; rất th&ocirc;ng dụng tr&ecirc;n thế giới , tuy nhi&ecirc;n Gỗ MINH ĐO&Agrave;N được đưa v&agrave;o sử dụng nội thất th&igrave; c&ograve;n rất mới mẻ, nhất l&agrave; với Việt Nam. Trong thời gian gần đ&acirc;y, người ti&ecirc;u d&ugrave;ng Việt Nam n&oacute;i chung v&agrave; ở c&aacute;c trung t&acirc;m th&agrave;nh phố lớn như H&agrave; Nội, TP Hồ Ch&iacute; Minh&hellip; đ&atilde; dần quen với kh&aacute;i niệm &ldquo; Nội Thất từ gỗ MINH ĐO&Agrave;N&rdquo;.<br />\nXuất phất từ nhu cầu thực tế tr&ecirc;n, c&ugrave;ng với mục đ&iacute;ch l&agrave; t&aacute;i sử dụng nguồn t&agrave;i nguy&ecirc;n gỗ Tự nhi&ecirc;n sẽ g&oacute;p phần giảm tải , hạn chế việc sử dụng nguồn gỗ tự nhi&ecirc;n từ Rừng xanh. Đồng thời, gi&uacute;p cho người ti&ecirc;u d&ugrave;ng c&oacute; thể tiếp cận dễ d&agrave;ng với c&aacute;c Sản phẩm nội thất từ gỗ tự nhi&ecirc;n m&agrave; vẫn hợp l&yacute; về gi&aacute; th&agrave;nh sản phẩm. Ch&uacute;ng t&ocirc;i- TRUNG T&Acirc;M NỘI THẤT MINH ĐO&Agrave;N &nbsp;l&agrave; một cơ sở sản xuất, thi c&ocirc;ng c&aacute;c sản phẩm từ gỗ MINH ĐO&Agrave;N Th&ocirc;ng h&agrave;ng đầu tại H&agrave; Nội cũng như tại Việt Nam.<br />\nĐược th&agrave;nh lập từ năm 2008 với đội ngũ nh&acirc;n sự l&agrave; c&aacute;c cử nh&acirc;n Kinh tế, Kiến tr&uacute;c&hellip;c&ugrave;ng với đội ngũ thợ l&agrave;nh nghề l&acirc;u năm lu&ocirc;n l&agrave;m việc tr&ecirc;n t&igrave;nh thần: &ldquo; Lợi &iacute;ch cho kh&aacute;ch h&agrave;ng l&agrave; số 1&rdquo;.<br />\nTại thị trường H&agrave; Nội cũng như c&aacute;c tỉnh ph&iacute;a Bắc c&aacute;c sản phẩm, dịch vụ của Nội thất MINH ĐO&Agrave;N đ&atilde; được sự đ&aacute;nh gi&aacute; rất cao từ người ti&ecirc;u d&ugrave;ng. Với mong muốn đem lại những sản phẩm Nội thất độc đ&aacute;o về phong c&aacute;ch, tinh tế từ chi tiết sản phẩm v&agrave; tiết kiệm chi ph&iacute; cho nguyện vọng được sở hữu c&aacute;c đồ nội thất từ Gỗ MINH ĐO&Agrave;N , ch&uacute;ng t&ocirc;i đ&atilde;, đang v&agrave; sẽ đem đến cho kh&aacute;ch h&agrave;ng những g&igrave; c&aacute;c bạn mong muốn.<br />\nNỘI THẤT MINH ĐO&Agrave;N cũng xin ch&acirc;n th&agrave;nh cảm ơn c&aacute;c qu&yacute; kh&aacute;ch h&agrave;ng đ&atilde; tin tưởng, ủng hộ sử dụng c&aacute;c sản phẩm dịch vụ của ch&uacute;ng t&ocirc;i trong suốt thời gian qua v&agrave; rất h&acirc;n hạnh được phục vụ nhiều hơn nữa cho qu&yacute; vị trong thời gian tới.<br />\nCh&acirc;n th&agrave;nh cảm ơn!<br />\nNỘI THẤT MINH ĐO&Agrave;N</p>\n', 1, 'about', 'Giới thiệu'),
(5, 'Liên kết', 1463117872, 'huychuc01@gmail.com', 1463117872, 'huychuc01@gmail.com', '<p>&nbsp;testtesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttesttest</p>\n', 1, 'customer_care', 'Liên kết');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`),
  ADD KEY `rule_name` (`rule_name`),
  ADD KEY `type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`),
  ADD KEY `child` (`child`);

--
-- Indexes for table `auth_item_group`
--
ALTER TABLE `auth_item_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `banner`
--
ALTER TABLE `banner`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auth_item_group`
--
ALTER TABLE `auth_item_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `banner`
--
ALTER TABLE `banner`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
